package com.nseindia.b2.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeLeaveManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
