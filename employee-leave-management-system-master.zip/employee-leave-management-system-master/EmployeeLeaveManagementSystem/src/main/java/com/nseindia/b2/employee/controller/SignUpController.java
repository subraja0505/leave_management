package com.nseindia.b2.employee.controller;

import com.nseindia.b2.employee.database.UserRepository;
import com.nseindia.b2.employee.model.UserRegistration;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/signup")
public class SignUpController {
	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;

	public SignUpController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
		this.userRepository = userRepository;
		this.passwordEncoder = passwordEncoder;
	}

	@GetMapping
	public String signUp() {
		return "signup";
	}

	@PostMapping
	public String processSignUp(UserRegistration userRegistration) {
		userRepository.save(userRegistration.toEmployee(passwordEncoder));
		userRepository.findAll().forEach(System.out::println);
		return "redirect:";
	}
}
