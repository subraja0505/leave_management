package com.nseindia.b2.employee.controller;

import com.nseindia.b2.employee.database.UserRepository;
import com.nseindia.b2.employee.model.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Controller
@RequestMapping("/manage")
public class AdminController {
    private final UserRepository userRepository;

    public AdminController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping
    public ModelAndView manage() {
        Iterable<Employee> employeeList = userRepository.findAll();
        return new ModelAndView("manageDashboard", "employeeList", employeeList);
    }

    @GetMapping("/subordinates/{employeeId}")
    public String manageSubordinates(Model model, @PathVariable Long employeeId) {
        Employee employee = userRepository.findById(employeeId).orElse(null);

        model.addAttribute("employee", employee);
        Iterable<Employee> currentSubordinates = employee.getSubordinates();
        model.addAttribute("currentSubordinates", currentSubordinates);
        Iterable<Employee> employeeWithoutManager = userRepository.findAllWithoutManagerForEmployee(employee.getUsername());
        model.addAttribute("employeeWithoutManager", employeeWithoutManager);

        return "manageSubordinates";
    }

    @PostMapping("/subordinates/{employeeId}")
    public String modifySubordinates(@PathVariable Long employeeId, @RequestParam Set<Long> subordinateIds) {
        userRepository.findById(employeeId).ifPresent(manager -> {
            manager.getSubordinates().stream()
                    .filter(subordinate -> !subordinateIds.contains(subordinate.getId()))
                    .forEach(subordinate -> {
                        subordinate.setManager(null);
                        userRepository.save(subordinate);
                    });
            userRepository.findAllById(subordinateIds).forEach(subordinate -> {
                if (!subordinate.getId().equals(employeeId) && subordinate.getManager() == null) {
                    subordinate.setManager(manager);
                    userRepository.save(subordinate);
                }
            });
        });

        return "redirect:/manage";
    }
}
