package com.nseindia.b2.employee.database;

import com.nseindia.b2.employee.model.Leave;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Safeuq Mohamed
 */
@Repository
public interface LeaveRepository extends CrudRepository<Leave, Long> {
    @Query("from Leave l inner join l.employee as e where e.id = :employeeId and l.isApproved = false")
    List<Leave> findAllUnapprovedLeaveForEmployee(Long employeeId);
}
