package com.nseindia.b2.employee.database;

import com.nseindia.b2.employee.model.Employee;
import com.nseindia.b2.employee.model.Leave;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends CrudRepository<Employee, Long> {
    Employee findByUsername(String emailAddress);

    @Query("from Employee e where e.manager is null and e.username <> :username")
    List<Employee> findAllWithoutManagerForEmployee(String username);
}
