package com.nseindia.b2.employee.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.security.crypto.password.PasswordEncoder;

@Getter
@Setter
@ToString
public class UserRegistration {
    private String email;
    private String password;
    private String confirmPassword;
    private String firstName;
    private String lastName;

    public Employee toEmployee(PasswordEncoder passwordEncoder) {
        return new Employee(email, passwordEncoder.encode(password), firstName, lastName);
    }
}
