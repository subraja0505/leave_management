package com.nseindia.b2.employee.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
public class Leave {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Long id;

    @Setter
    @ManyToOne
    private Employee employee;

    private Date startDate;
    private Date endDate;
    private String reason;

    @Setter
    private boolean isApproved;

    public Leave(Date startDate, Date endDate, String reason) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.reason = reason;
    }

    public Leave() {
    }

    public String toString() {
        return "Leave(" +
                "id=" + this.getId() + ", " +
                "employee=" + this.getEmployee().getFullName() + ", " +
                "startDate=" + this.getStartDate() + ", " +
                "endDate=" + this.getEndDate() + ", " +
                "reason=" + this.getReason() + ", " +
                "isApproved=" + this.isApproved() + ")";
    }
}
