package com.nseindia.b2.employee.controller;

import com.nseindia.b2.employee.database.LeaveRepository;
import com.nseindia.b2.employee.database.UserRepository;
import com.nseindia.b2.employee.model.Employee;
import com.nseindia.b2.employee.model.Leave;
import com.nseindia.b2.employee.model.LeaveForm;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.*;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/leave")
public class LeaveController {
    private final UserRepository userRepository;
    private final LeaveRepository leaveRepository;

    public LeaveController(UserRepository userRepository, LeaveRepository leaveRepository) {
        this.userRepository = userRepository;
        this.leaveRepository = leaveRepository;
    }

    @GetMapping
    protected ModelAndView getLeave(@AuthenticationPrincipal Employee employee) {
        Employee employeeFull = userRepository.findByUsername(employee.getUsername());
        List<Leave> leaveList = employeeFull.getLeaveList();
        return new ModelAndView("leaveDashboard", "leaveList", leaveList);
    }

    @GetMapping("/approve")
    protected String getPendingApproval(@AuthenticationPrincipal Employee employee, Model model) {
        Employee employeeFull = userRepository.findByUsername(employee.getUsername());
        List<Employee> subordinates = employeeFull.getSubordinates();
        Map<Long, List<Leave>> leaveMap = subordinates.stream()
                .collect(Collectors.toMap(Employee::getId, emp ->
                        leaveRepository.findAllUnapprovedLeaveForEmployee(emp.getId())));
        model.addAttribute("leaveMap", leaveMap);
        model.addAttribute("subordinates", subordinates.stream()
                .filter(emp -> !leaveMap.getOrDefault(emp.getId(), Collections.emptyList()).isEmpty())
                .collect(Collectors.toList()));

        return "approvalDashboard";
    }

    @PostMapping("/approve")
    protected String approveLeave(@AuthenticationPrincipal Employee manager, Model model, @RequestParam Set<Long> leaveIds) {
        for (Long leaveId : leaveIds) {
            Leave leave = leaveRepository.findById(leaveId).orElse(null);
            if (leave != null) {
                if (manager.getId().equals(leave.getEmployee().getManager().getId())) {
                    leave.setApproved(true);
                    leaveRepository.save(leave);
                }
            }
        }

        return "redirect:/";
    }

    @GetMapping("/add")
    private String addLeave() {
        return "addLeave";
    }

    @PostMapping("/add")
    private String processLeaveAdd(LeaveForm leaveForm, @AuthenticationPrincipal Employee employee) {
        if (leaveForm.getReason() != null) {
            Leave leave = leaveForm.toLeave();
            leave.setEmployee(employee);
            leaveRepository.save(leave);
        }
        System.out.println(leaveForm);
        return "redirect:/leave";
    }
}
